%GridFileName=['cavmpA.grd'];

a=fopen([GridFileName]);

%%% Read some parameters and dimensions
NXA   =fread(a,1,'int32'); 
NYA   =fread(a,1,'int32');
NZA   =fread(a,1,'int32');
NXYZA =fread(a,1,'int32');
NIA   =fread(a,1,'int32');
NOA   =fread(a,1,'int32');
NSA   =fread(a,1,'int32');
NWA   =fread(a,1,'int32');
NOCA  =fread(a,1,'int32');
NWALI =fread(a,1,'int32');
NWALA =fread(a,1,'int32');
NIAX  =fread(a,1,'int32');
NOAX  =fread(a,1,'int32');
NSAX  =fread(a,1,'int32');
NWAX  =fread(a,1,'int32');
NOCX  =fread(a,1,'int32');

%%% Read some indexes
LI    =fread(a,NXA,'int32');
LK    =fread(a,NZA,'int32');

%%% Read Indexes for B.C.s
IJI   =fread(a,NIAX,'int32');
IJPI  =fread(a,NIAX,'int32');
IJI1  =fread(a,NIAX,'int32');
IJI2  =fread(a,NIAX,'int32');
IJI3  =fread(a,NIAX,'int32');
IJI4  =fread(a,NIAX,'int32');
ITAGI =fread(a,NIAX,'int32');
%
IJO   =fread(a,NOAX,'int32');
IJPO  =fread(a,NOAX,'int32');
IJO1  =fread(a,NOAX,'int32');
IJO2  =fread(a,NOAX,'int32');
IJO3  =fread(a,NOAX,'int32');
IJO4  =fread(a,NOAX,'int32');
ITAGO =fread(a,NOAX,'int32');
%
IJW   =fread(a,NWAX,'int32');
IJPW  =fread(a,NWAX,'int32');
IJW1  =fread(a,NWAX,'int32');
IJW2  =fread(a,NWAX,'int32');
IJW3  =fread(a,NWAX,'int32');
IJW4  =fread(a,NWAX,'int32');
ITAGW =fread(a,NWAX,'int32');
%
IJS   =fread(a,NSAX,'int32');
IJPS  =fread(a,NSAX,'int32');
IJS1  =fread(a,NSAX,'int32');
IJS2  =fread(a,NSAX,'int32');
IJS3  =fread(a,NSAX,'int32');
IJS4  =fread(a,NSAX,'int32');
ITAGS =fread(a,NSAX,'int32');
%
IJL   =fread(a,NOCX,'int32');
IJR   =fread(a,NOCX,'int32');
IJOC1 =fread(a,NOCX,'int32');
IJOC2 =fread(a,NOCX,'int32');
IJOC3 =fread(a,NOCX,'int32');
IJOC4 =fread(a,NOCX,'int32');
ITAGOC=fread(a,NOCX,'int32');
%

%%% Read grid data
X     =fread(a,NXYZA,'single');
Y     =fread(a,NXYZA,'single');
Z     =fread(a,NXYZA,'single');
XC    =fread(a,NXYZA,'single');
YC    =fread(a,NXYZA,'single');
ZC    =fread(a,NXYZA,'single');
FX    =fread(a,NXYZA,'single');
FY    =fread(a,NXYZA,'single');
FZ    =fread(a,NXYZA,'single');
VOL   =fread(a,NXYZA,'single');
SRDW  =fread(a,NWAX,'single');
XNW   =fread(a,NWAX,'single');
YNW   =fread(a,NWAX,'single');
ZNW   =fread(a,NWAX,'single');
SRDS  =fread(a,NSAX,'single');
XNS   =fread(a,NSAX,'single');
YNS   =fread(a,NSAX,'single');
ZNS   =fread(a,NSAX,'single');
FOC   =fread(a,NOCX,'single');
%

fclose(a);

X=reshape(X,NYA,NXA,NZA);
Y=reshape(Y,NYA,NXA,NZA);
Z=reshape(Z,NYA,NXA,NZA);
XC=reshape(XC,NYA,NXA,NZA);
YC=reshape(YC,NYA,NXA,NZA);
ZC=reshape(ZC,NYA,NXA,NZA);
FX=reshape(FX,NYA,NXA,NZA);
FY=reshape(FY,NYA,NXA,NZA);
FZ=reshape(FZ,NYA,NXA,NZA);
VOL=reshape(VOL,NYA,NXA,NZA);
