function h=gridsurf(XC,YC,ZC,sc,fh);

h=figure(fh);
hold on;
nn=size(XC);
hs=[];

for perm=1:3,
    
    XC=permute(XC,[3,1,2]);
    YC=permute(YC,[3,1,2]);
    ZC=permute(ZC,[3,1,2]);    
    
    hi=surf(XC(:,:,1),YC(:,:,1),ZC(:,:,1));
    set(hi,'FaceColor',sc);
    hs=[hs;hi];
    
    hi=surf(XC(:,:,end),YC(:,:,end),ZC(:,:,end));
    set(hi,'FaceColor',sc);
    hs=[hs;hi];
    
end;
