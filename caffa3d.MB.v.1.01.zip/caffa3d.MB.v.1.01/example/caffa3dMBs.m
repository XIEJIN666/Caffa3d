%clear all
%%% Filename with appropiate path
%filnam=['cavmp1.10'];

%%% Open file
a=fopen(filnam);  

%%% Read dimensions, grid and flow data

ITIM=fread(a,1,'int32');        %   
TIME=fread(a,1,'single');       % time
NBLKS=fread(a,1,'int32');       % number of blocks
NIJKBKAL=fread(a,1,'int32');    % total number of points
%
NIBK=fread(a,NBLKS,'int32');    % NI    1..NBLKS
NJBK=fread(a,NBLKS,'int32');    % NJ    1..NBLKS 
NKBK=fread(a,NBLKS,'int32');    % NK    1..NBLKS
IBK=fread(a,NBLKS,'int32');     % IST   1..NBLKS
JBK=fread(a,NBLKS,'int32');     % JST   1..NBLKS
KBK=fread(a,NBLKS,'int32');     % KST   1..NBLKS 
IJKBK=fread(a,NBLKS,'int32');   % IJKST 1..NBLKS
NIJKBK=fread(a,NBLKS,'int32');  % NIJK  1..NBLKS
%
X=fread(a,NIJKBKAL,'single');   % X
Y=fread(a,NIJKBKAL,'single');   % Y
Z=fread(a,NIJKBKAL,'single');   % Z
Xc=fread(a,NIJKBKAL,'single');  % XC
Yc=fread(a,NIJKBKAL,'single');  % YC
Zc=fread(a,NIJKBKAL,'single');  % ZC
%
f1=fread(a,NIJKBKAL,'single');  % F1
f2=fread(a,NIJKBKAL,'single');  % F2
f3=fread(a,NIJKBKAL,'single');  % F3
U=fread(a,NIJKBKAL,'single');   % U
V=fread(a,NIJKBKAL,'single');   % V
W=fread(a,NIJKBKAL,'single');   % V    
P=fread(a,NIJKBKAL,'single');   % P
T=fread(a,NIJKBKAL,'single');   % T
M=fread(a,NIJKBKAL,'single');   % MU
R=fread(a,NIJKBKAL,'single');   % RES    

LGRAD=0;

if LGRAD==1,
    DUX=fread(a,NIJKBKAL,'single');   % grad    
    DUY=fread(a,NIJKBKAL,'single');   % grad    
    DUZ=fread(a,NIJKBKAL,'single');   % grad        
    DVX=fread(a,NIJKBKAL,'single');   % grad    
    DVY=fread(a,NIJKBKAL,'single');   % grad    
    DVZ=fread(a,NIJKBKAL,'single');   % grad        
    DWX=fread(a,NIJKBKAL,'single');   % grad    
    DWY=fread(a,NIJKBKAL,'single');   % grad    
    DWZ=fread(a,NIJKBKAL,'single');   % grad        
end;

%%% Sort grid data by block
for i=1:NBLKS,
    IJKV=[IJKBK(i)+1:IJKBK(i)+NIJKBK(i)];
    vv=[NJBK(i),NIBK(i),NKBK(i)];
    GR(i).XX=reshape(X(IJKV),vv);
    GR(i).YY=reshape(Y(IJKV),vv);
    GR(i).ZZ=reshape(Z(IJKV),vv);
    GR(i).XC=reshape(Xc(IJKV),vv);
    GR(i).YC=reshape(Yc(IJKV),vv);
    GR(i).ZC=reshape(Zc(IJKV),vv);
end;

%%% Sort flow data by block
for i=1:NBLKS,
    IJKV=[IJKBK(i)+1:IJKBK(i)+NIJKBK(i)];
    vv=[NJBK(i),NIBK(i),NKBK(i)];
    FL(i).F1(:,:,:)=reshape(f1(IJKV),vv);
    FL(i).F2(:,:,:)=reshape(f2(IJKV),vv);        
    FL(i).F3(:,:,:)=reshape(f3(IJKV),vv);
    FL(i).UU(:,:,:)=reshape(U(IJKV),vv);        
    FL(i).VV(:,:,:)=reshape(V(IJKV),vv);
    FL(i).WW(:,:,:)=reshape(W(IJKV),vv);    
    FL(i).TT(:,:,:)=reshape(T(IJKV),vv);        
    %FL(i).PP(:,:,:)=reshape(P(IJKV),vv);
    FL(i).MU(:,:,:)=reshape(M(IJKV),vv);        
    %FL(i).RE(:,:,:)=reshape(R(IJKV),vv);                
    if LGRAD,
        FL(i).DUX(:,:,:)=reshape(DUX(IJKV),vv);                
        FL(i).DUY(:,:,:)=reshape(DUY(IJKV),vv);                
        FL(i).DUZ(:,:,:)=reshape(DUZ(IJKV),vv);                        
        FL(i).DVX(:,:,:)=reshape(DVX(IJKV),vv);                
        FL(i).DVY(:,:,:)=reshape(DVY(IJKV),vv);                
        FL(i).DVZ(:,:,:)=reshape(DVZ(IJKV),vv);                        
        FL(i).DWX(:,:,:)=reshape(DWX(IJKV),vv);                
        FL(i).DWY(:,:,:)=reshape(DWY(IJKV),vv);                
        FL(i).DWZ(:,:,:)=reshape(DWZ(IJKV),vv);                        
    end;
end;

%%% Clean up
fclose(a);
clear X Y Z Xc Yc Zc f1 f2 f3 U V W P T M R aux IJKV vv a 
clear DUX DUY DUZ DVX DVY DVZ DWX DWY DWZ
%clear filnam 
%pack

return


